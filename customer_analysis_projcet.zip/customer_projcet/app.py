from flask import Flask, render_template, request, redirect, url_for
import pandas as pd

app = Flask(__name__)
product_data = {
    'season': ['Summer', 'Winter', 'Summer', 'Winter'],
    'category': ['Children', 'Men', 'Women', 'Children'],
    'product_name': ['T-Shirt', 'Jacket', 'Dress', 'Sweater']
}
df = pd.DataFrame(product_data)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/home')
def home():
    return render_template('home.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
       
        name = request.form['name']
        email = request.form['email']
       
        return redirect(url_for('home'))
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        return redirect(url_for('home'))
    return render_template('login.html')

@app.route('/products')
def products():
    return render_template('product.html', data=df.to_dict('records'))
if __name__ == '__main__':
    app.run(debug=True)
